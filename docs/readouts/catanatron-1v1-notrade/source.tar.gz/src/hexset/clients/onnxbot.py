"""A dropped-in ONNX checkpoint as an opponent.

This module is onnxruntime's half of the model boundary, and only that half:
loading a `.onnx` file, checking what it declares, and answering
`hexset.clients.policy.Policy` for it (`V2Policy`). How a checkpoint is
*played* -- the bot, the leaf evaluation, the search, the trade gate -- is
runtime-agnostic and lives in `hexset.clients.netbot`, so the same code seats
a torch checkpoint from the training repo. It used to live here, and the
training repo carried its own copy of all of it; the two drifted three ways
in the trade gate alone (`agents/reference/hexn-boundary-audit.md`).

The rest of the package still hands over a `Game` and gets an `Action` back,
and `spawn` below is the only entry point it needs. The names it has always
imported from this module -- `NetworkBot`,
`LeafEvaluator`, `GatedSearch` -- are re-exported here and mean exactly what
they did.

`V2Policy` is an onnxruntime `InferenceSession` with its own math in numpy --
mechanical, since none of it has learned parameters.

A checkpoint's `contract` metadata names which record shape it declares
(`5` — "record in, decision out": the graph itself masks,
normalises, argmaxes and un-rotates, and `V2Policy` just reads its outputs).

Contract 1 ("observation in, raw logits/give/want/value out", masked and
decoded here in Python against the frozen `encoding_v1` feature layout) is no
longer served — the owner dropped it 2026-09-02. A `contract=1` file, or one
with no `contract` key at all, is refused by name at load.
"""

from __future__ import annotations

import os
import random
from dataclasses import dataclass
from functools import lru_cache
from typing import Sequence

import numpy as np
import onnxruntime as ort

from hexset.actions import Action, ActionSpace, build_space
from hexset.board.topology import Topology
from hexset.clients.netbot import (
    GatedSearch,
    LeafEvaluator,
    NetworkBot,
    bot_for,
    register_entrants,
    searcher_for,
)
from hexset.game import Game
from hexset.mcts import Search
from hexset.onnx_record import record_from_game
from hexset.server.constants import RECORD_CONTRACTS
from hexset.clients.modelmeta import GateConfig, SearchConfig, gate_config, search_config
from hexset.actions import options_for

# What this module has always exported. `NetworkBot` and the other three are
# `hexset.clients.netbot`'s now -- re-exported by name so every existing
# `from hexset.clients.onnxbot import ...` keeps working, and because "the
# ONNX checkpoint's bot" is still what a caller here means by them.
__all__ = [
    "GatedSearch",
    "LeafEvaluator",
    "Loaded",
    "NetworkBot",
    "V2Policy",
    "load",
    "network_bot",
    "options_for",
    "register_entrants",
    "searcher",
    "spawn",
]


def _providers_for(device: str) -> list[str]:
    """onnxruntime's own provider names, not torch's device strings — `cpu`
    is the only one this repo actually runs on (no GPU on the boxes it
    targets), but the `--device` flag stays functional for anyone with a
    build that has a GPU execution provider available, falling back to CPU
    if it doesn't."""
    if not device or device == "cpu":
        return ["CPUExecutionProvider"]
    return [f"{device.upper()}ExecutionProvider", "CPUExecutionProvider"]


class V2Policy:
    """A record-contract checkpoint as a `hexset.clients.policy.Policy`: the
    graph itself masks, normalises, argmaxes and un-rotates, so this class
    only states the position and reads the graph's decision back.

    Structurally a `Policy` -- it inherits nothing, and `netbot`'s bot,
    evaluator, searcher and gate never learn which runtime they are holding,
    nor which of the record contracts this file declares.
    """

    def __init__(self, session: ort.InferenceSession, space: ActionSpace) -> None:
        self.session = session
        self.space = space

    def _run(
        self,
        rows: Sequence[tuple[Game, int, tuple[Action, ...]]],
        outputs: list[str],
    ) -> list[np.ndarray]:
        records = [record_from_game(game, seat, self.space, options) for game, seat, options in rows]
        return self._run_records(records, outputs)

    def _run_records(
        self, records: Sequence[dict[str, np.ndarray]], outputs: list[str]
    ) -> list[np.ndarray]:
        """`_run`'s second half, for a caller that has already built its own
        rows (`value_of`, below) rather than reading them off a live
        `(game, seat, options)` triple.

        Keyed off the graph's own input names, not off every field the
        record happens to carry. onnxruntime rejects a feed containing a
        name it does not declare, so this is exactly "give the graph the
        subset it asks for" -- and refuses loudly, below, if it asks for
        something a contract-5 record no longer carries (the four
        `offer_*` fields and `pair_mask`, gone with the offer protocol).
        """
        wanted = [i.name for i in self.session.get_inputs()]
        missing = [name for name in wanted if name not in records[0]]
        if missing:
            raise ValueError(
                f"this graph asks for {missing}, which the record does not carry — "
                "it was exported against a newer contract than this server builds"
            )
        inputs = {key: np.stack([record[key] for record in records]) for key in wanted}
        return self.session.run(outputs, inputs)

    def _batchable(self, count: int) -> bool:
        """Whether the graph's own declared input shapes allow a batch of
        `count` rows in one call.

        onnxruntime reports a dynamic batch axis as a non-`int` (a symbol
        name, or `None`); a graph traced with a fixed batch size reports a
        plain `int` there instead, and a feed of any other size is refused
        outright rather than silently rejected. `value_of` falls back to one
        call per row when this says no, rather than finding out the hard way.
        """
        for declared in self.session.get_inputs():
            shape = declared.shape
            if shape and isinstance(shape[0], int) and shape[0] != count:
                return False
        return True

    def value_of(self, records: Sequence[dict[str, np.ndarray]]) -> np.ndarray:
        """The value head alone, `(len(records), players)`, board-seat order,
        for a caller that has already built its own record rows.

        One graph call if the batch dimension allows every row at once
        (`_batchable`); otherwise one call per row, in declared order. A
        fixed-batch-1 graph then pays for six forwards where a dynamic-batch
        one pays for one, which is a property of the exported graph, not of
        this method.
        """
        if not records:
            return np.zeros((0, 0), dtype=np.float32)
        if self._batchable(len(records)):
            (value,) = self._run_records(records, ["value"])
            return value
        rows = [self._run_records([record], ["value"])[0][0] for record in records]
        return np.stack(rows)

    def act_rows(self, rows: Sequence[tuple[Game, int, tuple[Action, ...]]]) -> list[Action]:
        if not rows:
            return []
        (action_index,) = self._run(rows, ["action_index"])
        return [self.space.decode(int(a)) for a in action_index]

    def value_rows(self, rows: Sequence[tuple[Game, int]]) -> list[tuple[float, ...]]:
        """`value`, already in board-seat order — the graph un-rotates it
        itself. `options_for` stands in for this row's options, since a bare
        `(game, seat)` value query has none to offer, and an empty mask would
        leave the graph nothing legal to normalise over.

        Through `value_of`, not `_run`, so that a whole wave of positions --
        `netbot.NetworkBot`'s imagined post-trade hands ask for one row per
        candidate -- still loads a fixed-batch graph one row at a time
        instead of being refused outright.
        """
        if not rows:
            return []
        records = [
            record_from_game(game, seat, self.space, options_for(game))
            for game, seat in rows
        ]
        return [tuple(float(v) for v in row) for row in self.value_of(records)]

    def score_rows(
        self, rows: Sequence[tuple[Game, int, tuple[Action, ...]]]
    ) -> list[tuple[np.ndarray, tuple[float, ...]]]:
        prior, value = self._run(rows, ["prior", "value"])
        return [
            (
                self._combine_prior(options, prior[i]),
                tuple(float(v) for v in value[i]),
            )
            for i, (_, _, options) in enumerate(rows)
        ]

    def _combine_prior(self, options, prior: np.ndarray) -> np.ndarray:
        """A leaf's options, scored from this row's dense prior."""
        weights = np.empty(len(options))
        for i, option in enumerate(options):
            weights[i] = prior[self.space.index(option)]
        total = weights.sum()
        if total <= 0:
            return np.full(len(options), 1.0 / len(options))
        return weights / total


@dataclass(frozen=True)
class Loaded:
    """A checkpoint made playable, plus what the run it came from was doing.

    `hexset.clients.policy.Checkpoint`, plus the two facts only a served
    file carries: which search it was exported to be played with, and which
    training iteration it is.
    """

    policy: V2Policy
    space: ActionSpace
    players: int
    max_trades: int | None
    iteration: int
    search: SearchConfig = SearchConfig()
    gate: GateConfig = GateConfig()

    @property
    def trade_floor(self) -> float:
        return self.gate.trade_floor

    @property
    def gate_rows(self) -> int:
        return self.gate.rows


@lru_cache(maxsize=4)
def _load_cached(
    path: str, topology: Topology, device: str, mtime_ns: int, threads: int | None
) -> Loaded:
    options = ort.SessionOptions()
    if threads is not None:
        options.intra_op_num_threads = threads
        options.inter_op_num_threads = threads
    session = ort.InferenceSession(
        str(path), sess_options=options, providers=_providers_for(device)
    )
    meta = session.get_modelmeta().custom_metadata_map

    players = int(meta["players"])
    # The topology fingerprint the training repo's exporter embeds: a graph
    # traced for one board shape fails silently if fed another (wrong-shaped
    # inputs, or worse, right-shaped-but-meaningless ones) rather than
    # loudly the way `net.load_state_dict` fails on a shape mismatch today
    # — so this is the loud failure standing in for that one.
    fingerprint = (
        int(meta["num_hexes"]),
        int(meta["num_vertices"]),
        int(meta["num_edges"]),
    )
    actual = (topology.num_hexes, topology.num_vertices, topology.num_edges)
    if fingerprint != actual:
        raise ValueError(
            f"{path} was exported for a board shaped {fingerprint} "
            f"(hexes, vertices, edges), not this table's {actual}"
        )

    space = build_space(
        topology.num_vertices, topology.num_edges, topology.num_hexes, players
    )
    contract = meta.get("contract", "1")
    if contract not in RECORD_CONTRACTS:
        # Loudly, rather than guessing at a graph shape and dying on the
        # first move with a missing-input error naming tensors nobody asked
        # about. Contract 1 (or no `contract` key at all) is refused here by
        # the same path as a genuinely unknown future contract — the owner
        # dropped it 2026-09-02, and there is no legacy path left to fall
        # back to.
        raise ValueError(
            f"{path} declares contract={contract!r}, which this server does not serve "
            f"(known: {', '.join(sorted(RECORD_CONTRACTS))})"
        )
    policy = V2Policy(session, space)
    max_trades = meta.get("max_trades") or None
    return Loaded(
        policy=policy,
        space=space,
        players=players,
        max_trades=int(max_trades) if max_trades is not None else None,
        iteration=int(meta.get("iteration", 0)),
        search=search_config(meta),
        gate=gate_config(meta),
    )


def load(
    path: str, topology: Topology, device: str = "cpu", threads: int | None = None
) -> Loaded:
    """The checkpoint at `path`, ready to act on boards of this topology.

    Cache key folds in the file's mtime, unlike the training repo's loader: its
    `.pt` checkpoints under `runs/` are effectively immutable per-run
    artifacts, but hexset's whole pitch is replacing a file in `models/`
    by name — without the mtime, a same-named replacement would silently
    keep serving the old in-memory session.

    `threads` caps onnxruntime's intra- and inter-op pools. Left `None`,
    onnxruntime sizes them from the core count, which is right for one bot at
    one table and wrong for a caller that has already sharded the work across
    processes -- each would claim the whole machine. Such a caller passes 1.
    """
    return _load_cached(path, topology, device, os.stat(path).st_mtime_ns, threads)


def searcher(
    path: str,
    board,
    *,
    simulations: int = 128,
    wave: int = 16,
    max_trades: int | None = None,
    device: str = "cpu",
    inference_batch: int | None = None,
    rng=None,
    threads: int | None = None,
) -> Search:
    """The checkpoint at `path` as a batched PUCT search, playing on `board`,
    trading through the checkpoint's own value-head gate
    (`hexset.clients.netbot.GatedSearch`)."""
    return searcher_for(
        load(path, board.topology, device, threads),
        simulations=simulations,
        wave=wave,
        max_trades=max_trades,
        inference_batch=inference_batch,
        rng=rng,
    )


def network_bot(
    path: str,
    board,
    *,
    max_trades: int | None = None,
    device: str = "cpu",
    threads: int | None = None,
) -> NetworkBot:
    """The checkpoint at `path`, playing on `board`."""
    return bot_for(load(path, board.topology, device, threads), max_trades=max_trades)


def spawn(
    path: str,
    board,
    *,
    rng: random.Random | None = None,
    device: str = "cpu",
    max_trades: int | None = None,
    threads: int | None = None,
):
    """The checkpoint at `path` as something with `.choose(game) -> Action`.

    The only entry point the rest of the package needs. Whether the file plays
    a single forward pass or a search over its own priors is the file's own
    business, declared in its metadata and read here — a caller passes a path
    and gets a bot, and never learns which it got.

    `device` is deliberately not read from metadata: it is a fact about the
    machine serving the game, not about the checkpoint, and a model file has no
    business demanding an accelerator its host may not have.
    """
    loaded = load(path, board.topology, device, threads)
    if not loaded.search.searches:
        return network_bot(
            path, board, max_trades=max_trades, device=device, threads=threads
        )
    return searcher(
        path,
        board,
        simulations=loaded.search.simulations,
        wave=loaded.search.wave,
        max_trades=max_trades,
        device=device,
        rng=rng,
        threads=threads,
    )
