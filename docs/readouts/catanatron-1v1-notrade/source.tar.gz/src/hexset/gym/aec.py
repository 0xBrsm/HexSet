# SPDX-License-Identifier: GPL-3.0-only
"""`HexSetAEC`: a PettingZoo AEC environment around the HexSet engine.

One agent
per seat (`seat_0`..`seat_{n-1}`), `agent_selection` naming the one seat
entitled to act next; `observe(agent)` never reads more than `agent`'s own
information set.

**Whose step it is.** `agent_selection` is `hexset.game.to_move` in every
phase but one. `Phase.DISCARD` is not a turn: every seat over the limit owes
its cards at the same instant and none of them waits on any other
(`hexset.game.may_act`, and the live server that asks it). AEC still wants
exactly one active agent per `step()`, so this environment picks one of the
owing seats -- but it picks *among* them rather than always taking the
lowest-indexed one, which is a fiction no table has. `discard_order`
says how:

- `"random"` (default) draws uniformly from the seats still owing, from a
  stream seeded off `reset(seed)` alone and never shared with the game's own
  rng -- a fixed seed still deals a fixed game and now also a fixed discard
  order.
- `"seat"` is the ascending order this environment used to hardcode, kept
  for a caller that wants the engine's own serialization back.
- `select_agent(agent)` overrides either, for any seat `may_act` allows: a
  caller replaying a real table's arrival order (`hexset.record`), or
  driving an experiment, names the seat itself.

Ascending-by-default was not merely arbitrary, it was biased: under it seat 0
never observes another seat's discard before choosing its own and the last
owing seat always observes all of them, so a self-play corpus taught the
policy an ordering that a live table does not have.

**Honesty.** Every observation array comes from `hexset.encoding.encode`,
which is already information-set correct by construction (own hand and
own development cards exact, everyone else a count plus the ledger's
public-knowledge reconstruction -- see that module's docstring). The
`action_mask` is the engine's own `hexset.actions.legal_actions`, which is
now honest by construction: the one branch that read opponents' true hands
was the `PROPOSE_TRADE` sample (who could cover an offer), and trading is
no longer an action at all (`hexset.trading`). Every action in the space
also decodes exactly from its index, so a random policy sampling the flat
`Discrete` space needs no filling-in either -- the interim random-offer
fill this environment carried is gone with the slot it filled.

**Trading.** A seat trades by answering a private gate (`gains_many`), not
by taking an action, and this environment seats no gate for its own agents:
`self._game.gates` stays `None` here, so nothing clears at all.
`hexset.gym.HexSetEnv` seats real bots for the non-learner seats and does
supply theirs. The learner's own gate is the deferred half of the
mechanic's interface (a human/LLM trading surface is server-side work), so
it is not in the action space here.
"""

from __future__ import annotations

import random
from functools import lru_cache
from typing import Any

import numpy as np
from gymnasium import spaces
from pettingzoo.utils.env import AECEnv

from hexset import encoding
from hexset.actions import Action, ActionSpace, apply, build_space, legal_actions
from hexset.board.board import random_base_board
from hexset.board.maps import BASE_LAYOUT
from hexset.board.topology import build as build_topology
from hexset.game import Game, Phase, is_over, may_act, players_owing_discards, start, to_move
from hexset.victory import relative_points, victory_points

REWARD_MODES = ("terminal", "relative_points")
# How `agent_selection` picks one of the seats owing a discard. See the module
# docstring: the round itself is order-invariant, so this decides only who is
# asked first, never what position the round reaches.
DISCARD_ORDERS = ("random", "seat")

# The standard board's topology never varies with terrain, tokens, ports or
# seed -- only `hexset.board.maps.BASE_LAYOUT`'s hex coordinates decide vertex
# and edge counts -- so it is built once here rather than once per episode,
# and shared with `hexset.gym.env` for its own space bookkeeping.
TOPOLOGY = build_topology(BASE_LAYOUT)


def agent_name(seat: int) -> str:
    return f"seat_{seat}"


class HexSetAEC(AECEnv):
    """One agent per seat on the standard board.

    `reward="terminal"` (default): +1 to the winning seat, 0 to everyone
    else, on the step the game ends; 0 on every other step.
    `reward="relative_points"`: each seat's terminal victory points less the
    mean of the others, over 10 (`hexset.victory.relative_points`) -- zero-sum,
    read only on the terminal step.

    Hitting `hexset.game.MAX_TURNS` ends the game with `won_by is None`; every
    agent's `truncations` entry is set (not `terminations`), reward 0,
    mirroring the arena's own `exhausted` outcome.

    `discard_order="random"` (default) / `"seat"`: which of the seats owing a
    seven's discards is named next, see the module docstring. Either way the
    round reaches the same position -- `discard_order` decides who is asked
    first, not what happens.
    """

    metadata = {"render_modes": ["ansi", "human"], "name": "hexset_v0", "is_parallelizable": False}

    def __init__(
        self,
        num_players: int = 4,
        *,
        reward: str = "terminal",
        discard_order: str = "random",
        render_mode: str | None = None,
    ) -> None:
        super().__init__()
        if not 2 <= num_players <= 6:
            raise ValueError(f"unsupported player count: {num_players}")
        if reward not in REWARD_MODES:
            raise ValueError(f"unknown reward mode {reward!r}, expected one of {REWARD_MODES}")
        if discard_order not in DISCARD_ORDERS:
            raise ValueError(
                f"unknown discard order {discard_order!r}, expected one of {DISCARD_ORDERS}"
            )

        self.num_players = num_players
        self.reward_mode = reward
        self.discard_order = discard_order
        self.render_mode = render_mode

        self.possible_agents: list[str] = [agent_name(s) for s in range(num_players)]
        self.agents: list[str] = []

        self._space: ActionSpace = build_space(
            TOPOLOGY.num_vertices, TOPOLOGY.num_edges, TOPOLOGY.num_hexes, num_players
        )
        self._game: Game | None = None
        # Its own stream, seeded off `reset(seed)` and nothing else: drawing
        # the discard order from the game's rng would deal a different board
        # for the same seed the first time a seven landed.
        self._discard_rng = random.Random("discard-order:None")

        self.rewards: dict[str, float] = {}
        self._cumulative_rewards: dict[str, float] = {}
        self.terminations: dict[str, bool] = {}
        self.truncations: dict[str, bool] = {}
        self.infos: dict[str, dict[str, Any]] = {}
        self.agent_selection: str | None = None

    # -- spaces ---------------------------------------------------------

    @lru_cache(maxsize=None)
    def observation_space(self, agent: str) -> spaces.Space:
        del agent  # identical for every seat at a fixed player count
        n = self.num_players
        return spaces.Dict(
            {
                "observation": spaces.Dict(
                    {
                        "hexes": spaces.Box(
                            -np.inf, np.inf, (TOPOLOGY.num_hexes, encoding.HEX_FEATURES), dtype=np.float32
                        ),
                        "vertices": spaces.Box(
                            -np.inf,
                            np.inf,
                            (TOPOLOGY.num_vertices, encoding.vertex_features(n)),
                            dtype=np.float32,
                        ),
                        "edges": spaces.Box(
                            -np.inf, np.inf, (TOPOLOGY.num_edges, encoding.edge_features(n)), dtype=np.float32
                        ),
                        "globals": spaces.Box(
                            -np.inf, np.inf, (encoding.global_features(n),), dtype=np.float32
                        ),
                    }
                ),
                "action_mask": spaces.Box(0, 1, (self._space.size,), dtype=np.int8),
            }
        )

    @lru_cache(maxsize=None)
    def action_space(self, agent: str) -> spaces.Space:
        del agent  # identical for every seat
        return spaces.Discrete(self._space.size)

    # -- AECEnv -----------------------------------------------------------

    def reset(self, seed: int | None = None, options: dict[str, Any] | None = None) -> None:
        del options
        rng = random.Random(seed)
        board = random_base_board(rng)
        self._game = start(board, self.num_players, rng)
        self._discard_rng = random.Random(f"discard-order:{seed}")

        self.agents = self.possible_agents[:]
        self.rewards = dict.fromkeys(self.agents, 0.0)
        self._cumulative_rewards = dict.fromkeys(self.agents, 0.0)
        self.terminations = dict.fromkeys(self.agents, False)
        self.truncations = dict.fromkeys(self.agents, False)
        self.infos = {a: {} for a in self.agents}
        self.agent_selection = self._next_agent(self._game)

    def select_agent(self, agent: str) -> None:
        """Name the seat that will act on the next `step()`, when more than
        one is entitled to.

        Only `Phase.DISCARD` ever entitles more than one: every seat still
        owing cards may act, in any order (`hexset.game.may_act`). This is how
        a caller that knows the order it wants -- a record replaying a real
        table's arrival order, a test, a training loop sampling orders itself
        -- says so, instead of accepting `discard_order`'s answer. Refuses any
        seat the engine would refuse, so it cannot be used to act out of turn.
        """
        game = self._game
        assert game is not None, "select_agent() called before reset()"
        if agent not in self.possible_agents:
            raise ValueError(f"no such agent: {agent!r}")
        seat = self.possible_agents.index(agent)
        if not may_act(game, seat):
            raise ValueError(f"{agent} may not act in {game.phase.name}")
        self.agent_selection = agent

    def observe(self, agent: str) -> dict[str, Any]:
        game = self._game
        assert game is not None, "observe() called before reset()"
        seat = self.possible_agents.index(agent)
        obs = encoding.encode(game, perspective=seat)

        mask = np.zeros(self._space.size, dtype=np.int8)
        # Per PettingZoo convention (`pettingzoo.classic.tictactoe`), the mask
        # is all zeros for every agent except the one about to act. It is that
        # agent's *own* options: during a discard round `agent_selection` is
        # any of the owing seats, not necessarily the one bare `legal_actions`
        # would answer for, so the seat is passed explicitly.
        if agent == self.agent_selection:
            for action in legal_actions(game, seat):
                mask[self._space.index(action)] = 1

        return {
            "observation": {
                "hexes": obs.hexes,
                "vertices": obs.vertices,
                "edges": obs.edges,
                "globals": obs.globals,
            },
            "action_mask": mask,
        }

    def step(self, action: int | Action | None) -> None:
        agent = self.agent_selection
        if self.terminations[agent] or self.truncations[agent]:
            self._was_dead_step(action)
            return

        game = self._game
        assert game is not None, "step() called before reset()"

        seat = self.possible_agents.index(agent)
        decoded = action if isinstance(action, Action) else self._space.decode(int(action))
        # The acting seat is dispatched with the action, not assumed from the
        # position: a `DISCARD` resolves against whoever `agent_selection`
        # names, which during a round is any owing seat. Every other action
        # belongs to `to_move` by construction and ignores the argument
        # (`hexset.actions.apply`).
        apply(game, decoded, seat)

        self._clear_rewards()
        if is_over(game):
            self._finish_episode(game, agent)
        else:
            self.agent_selection = self._next_agent(game)
        self._accumulate_rewards()

        if self.render_mode == "human":
            self.render()

    def render(self) -> str | None:
        if self._game is None:
            return None
        text = self._summary(self._game)
        if self.render_mode == "human":
            print(text)
            return None
        return text

    def close(self) -> None:
        self._game = None

    # -- internals --------------------------------------------------------

    def _next_agent(self, game: Game) -> str:
        """Which single agent AEC hands the next `step()` to.

        `to_move` everywhere except a seven's discards, where several seats
        are entitled at once and this picks one of them per `discard_order`
        rather than always the lowest-indexed. `to_move`'s own answer is that
        lowest-indexed seat, so `"seat"` needs no separate branch.
        """
        if self.discard_order == "random" and game.phase is Phase.DISCARD:
            owing = players_owing_discards(game)
            if owing:
                return agent_name(self._discard_rng.choice(owing))
        return agent_name(to_move(game))

    def _finish_episode(self, game: Game, acted_agent: str) -> None:
        won = game.won_by
        if self.reward_mode == "relative_points":
            points = tuple(
                victory_points(game.state(seat, hidden=False), seat) for seat in range(self.num_players)
            )
            values = relative_points(points)
            for seat, agent in enumerate(self.possible_agents):
                self.rewards[agent] = float(values[seat])
        else:
            for seat, agent in enumerate(self.possible_agents):
                self.rewards[agent] = 1.0 if seat == won else 0.0

        if won is not None:
            for a in self.agents:
                self.terminations[a] = True
        else:
            for a in self.agents:
                self.truncations[a] = True

        # `to_move(game)` is meaningless once the game is over. Any live agent
        # works here -- every one of them is now terminated/truncated, so the
        # next `step()` on whichever one `agent_selection` names takes the
        # dead-agent branch above -- so this just rotates deterministically.
        acted_seat = self.possible_agents.index(acted_agent)
        self.agent_selection = self.possible_agents[(acted_seat + 1) % self.num_players]

    def _summary(self, game: Game) -> str:
        # The acting agent, not `to_move`: during a discard round they differ,
        # and it is `agent_selection` that the next `step()` resolves against.
        lines = [f"turn {game.turns}, phase {game.phase.name}, acting {self.agent_selection}"]
        if game.won_by is not None:
            lines.append(f"winner: {agent_name(game.won_by)}")
        for seat in range(self.num_players):
            points = victory_points(game.state(seat, hidden=False), seat)
            lines.append(f"{agent_name(seat)}: {points} VP")
        return "\n".join(lines)
