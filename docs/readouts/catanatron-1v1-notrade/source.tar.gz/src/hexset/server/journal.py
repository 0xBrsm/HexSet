"""The server's own account of a game, written as the game happens.

One line per action, written the instant it is applied, with the hidden
information spelled out. The shuffled deck goes in the header, the dice on every
roll, the card drawn on every purchase, the resource taken on every steal, and
every seat's full hand and development cards afterwards. Nothing here needs the
engine to interpret it and nothing is held back — unlike the sidebar transcript,
which hides exactly what a player at the table could not see (see
`hexset.server.webplay._describe`).

It is the only thing written, and it is also what a game is resumed from:
`replayable` reads these lines back into actions and `GameSession.restore`
re-applies them. A second, more compact file beside this one would be a subset
that could only ever disagree with it.

One file per game, not one shared file appended to: sessions are concurrent (the
web server deals a session per browser), and lines from three games in flight
would have to be de-interleaved before any one of them could be read. Every line
is written and closed as it happens, so a game abandoned mid-turn — or a server
killed outright — leaves a complete account up to that point instead of nothing.

Writing is on by default and switched off by setting `HEXSET_UI_GAMES_DIR`
empty. A directory that cannot be written to disables this journal and lets the
game carry on: a game nobody can log is still a game, and a player mid-turn
should not lose it to a full disk.
"""

from __future__ import annotations

import json
import os
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Sequence

from hexset.actions import Action, ActionType
from hexset.board.board import Board
from hexset.board.terrain import NUM_RESOURCES, Resource
from hexset.cards import NUM_DEV_CARDS, DevCard
from hexset.devcards import holdings
from hexset.game import Game
from hexset.trading import Trade
from hexset.victory import victory_points

if TYPE_CHECKING:  # pragma: no cover - typing only
    from .webplay import RoundNote

ENV_DIR = "HEXSET_UI_GAMES_DIR"
DEFAULT_DIR = "games"

RESOURCE_NAMES: tuple[str, ...] = tuple(r.name for r in Resource)
DEV_CARD_NAMES: tuple[str, ...] = tuple(c.name for c in DevCard)


def board_fields(board: Board) -> dict[str, tuple]:
    """The board, spelled out for the header.

    Resuming rebuilds the board from the seed and never reads these back; they
    are here so the file can be understood without re-running the generator
    that made it, which is what this journal is for. Port vertices are left
    out — they follow from the edge for anyone rebuilding the topology.
    """
    return {
        "layout": tuple(tuple(h) for h in board.topology.hexes),
        "terrain": tuple(int(t) for t in board.terrain),
        "tokens": tuple(board.tokens),
        "ports": tuple(
            (p.edge, p.ratio, None if p.resource is None else int(p.resource))
            for p in board.ports
        ),
    }


def configured_dir() -> str | None:
    """Where games are journalled, or `None` when that is switched off.

    On by default, so a server started with no arguments at all still keeps
    a full account of every game it deals. Pointing the variable somewhere
    else moves the directory; setting it to the empty string is how you turn
    the journal off, which is a thing to say explicitly rather than the
    accident of having forgotten a flag.
    """
    value = os.environ.get(ENV_DIR, DEFAULT_DIR).strip()
    return value or None


def new_game_id(seed: int) -> str:
    """A per-game filename stem: when it was dealt, its seed, and enough
    randomness to keep two browsers that started the same second apart. The
    seed is in the name (as well as in the header) so the file matching a
    record can be found without opening any of them."""
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return f"{stamp}-seed{seed}-{uuid.uuid4().hex[:6]}"


def effects(
    game: Game,
    actor: int,
    action: Action,
    before_hands: list[list[int]],
    before_held: list[list[int]],
) -> dict:
    """The parts of an action's outcome the action itself does not carry.

    Everything an action decides is already in its own operands, and every
    resource that moved can be read off the hands recorded either side of it.
    What neither of those covers is what the engine's random stream decided:
    the dice, which card came off the deck, and which card a steal took. Those
    are the three things named here, and they are the three things a reader
    would otherwise have to re-run the engine to learn.
    """
    # true state: the journal is the record of everything that
    # happened, including outcomes no view would expose.
    state = game.state(0, hidden=False)
    out: dict = {}

    if action.type is ActionType.ROLL:
        out["roll"] = game.last_roll

    if action.type is ActionType.BUY_DEV_CARD:
        held = holdings(state, actor)
        drawn = [c for c in range(NUM_DEV_CARDS) if held[c] > before_held[actor][c]]
        if drawn:
            out["drew"] = DEV_CARD_NAMES[drawn[0]]

    if action.type is ActionType.MOVE_ROBBER:
        victim = action.b if action.b < state.num_players else None
        if victim is not None:
            taken = [
                r
                for r in range(NUM_RESOURCES)
                if state.hands[victim][r] < before_hands[victim][r]
            ]
            # A victim with an empty hand is a legal target, and nothing
            # moves: recorded as the steal that took nothing rather than
            # left out, so the log distinguishes it from a robber move that
            # named no victim at all.
            out["stole"] = {
                "from": victim,
                "resource": RESOURCE_NAMES[taken[0]] if taken else None,
            }

    return out


@dataclass
class Journal:
    """One game's file. Created open, and appended to until the game ends."""

    directory: str
    game_id: str
    # Flipped by the first write that fails, so a journal on a directory that
    # turns out to be read-only complains once instead of once per action.
    _off: bool = field(default=False, repr=False)

    @property
    def path(self) -> Path:
        return Path(self.directory) / f"{self.game_id}.jsonl"

    def _emit(self, event: dict) -> None:
        if self._off:
            return
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.path, "a", encoding="utf-8") as handle:
                handle.write(json.dumps(event, separators=(",", ":")) + "\n")
        except OSError as error:
            self._off = True
            print(f"game journal disabled ({self.path}): {error}")

    def start(
        self,
        game: Game,
        *,
        seed: int,
        first: int,
        human_seats: list[int],
        bot_names: dict[int, str],
        bot_specs: dict[int, str],
        player_names: dict[int, str] | None = None,
        clients: dict[int, dict] | None = None,
        code: str | None = None,
    ) -> None:
        """The header: everything true before the first action.

        The deck is the reason this line exists. It is the one piece of hidden
        state that is fixed at deal time and consumed silently thereafter —
        with the shuffle written down, every later purchase is checkable
        against it, and the whole game's development cards are known without
        the engine's random stream being involved at all.

        `code` is the table's join code and `spec` the string that built each
        bot, neither of which the game itself needs: they are here so a resume
        can put this exact table back together after a restart. `first` is the
        seat the setup snake started at (see `hexset.server.seating.start_at`) — needed
        to rebuild the same queue on resume, since it is a free per-table
        choice, not something derivable from `seed`/`num_players` alone.
        `human_seats` are the seats occupied at deal time (any kind — see
        `api.GameSession.claimed_seats`, the key name predates that) and
        `player_names` whatever they registered as — a seat missing from the
        latter is one nobody named. `clients` is `api.parse_client`'s record
        (`{"id", "kind"}`) for whichever of those seats claimed with one — a
        bot's or an unclaimed seat has no entry. A seat claiming in later, or
        a seat somebody closes outright, both show up as their own event kind
        (`seated`, `locked`) rather than here.
        """
        # true state: the journal is the record of everything that
        # happened, including outcomes no view would expose.
        state = game.state(0, hidden=False)
        self._emit(
            {
                "kind": "game",
                "id": self.game_id,
                "at": _now(),
                "seed": seed,
                "first": first,
                "code": code,
                "num_players": state.num_players,
                "human_seats": list(human_seats),
                "player_names": {str(s): n for s, n in sorted((player_names or {}).items())},
                "clients": {str(s): c for s, c in sorted((clients or {}).items())},
                "bots": {
                    str(seat): {"name": name, "spec": bot_specs.get(seat, name)}
                    for seat, name in sorted(bot_names.items())
                },
                # Bottom of the deck first: `devcards.buy` pops off the end.
                "deck": [DEV_CARD_NAMES[c] for c in state.deck],
                "robber": state.robber,
                **{k: list(v) for k, v in board_fields(state.board).items()},
            }
        )

    def action(
        self,
        game: Game,
        *,
        step: int,
        round_num: int,
        actor: int,
        action: Action,
        before_hands: list[list[int]],
        before_held: list[list[int]],
        trades: Sequence[Trade] = (),
    ) -> None:
        # true state: the journal is the record of everything that
        # happened, including outcomes no view would expose.
        state = game.state(0, hidden=False)
        event = {
            "kind": "action",
            "step": step,
            "round": round_num,
            "actor": actor,
            "type": action.type.name,
            "a": action.a,
            "b": action.b,
            **effects(game, actor, action, before_hands, before_held),
            # After, for every seat, not just the actor's: a roll pays several
            # players at once and a monopoly takes from all of them, so a
            # per-actor hand would make those actions unreadable. Absolute
            # counts rather than deltas, so any one line stands on its own
            # instead of being a correction to the lines before it.
            "hands": [hand[:] for hand in state.hands],
            "dev": [holdings(state, p) for p in range(state.num_players)],
            "deck_left": len(state.deck),
        }
        if trades:
            # The exchanges the engine cleared inside this action
            # (`hexset.trading`). Written down because they are not a
            # function of the action -- they depend on what every seat had
            # published -- so a replay cannot re-derive them.
            event["trades"] = [[t.a, t.b, list(t.received)] for t in trades]
        self._emit(event)

    def manual_trade(self, game: Game, *, step: int, round_num: int, trade: Trade) -> None:
        """A bundle executed outside the automatic event -- a proposal
        (`POST .../trade`) or a confirmed pending offer (`.../trade/
        confirm`) -- landed here as its own line rather than folded into
        some action's own (see `Journal.action`'s own `trades` field):
        nothing about the phase or the turn changed when it cleared, only
        two hands, so there is no action to attach it to.

        Replayed by `replayable`/`GameSession.restore` as its own step: the
        recorded `Trade` is re-executed directly (`hexset.trading.
        apply_trades`), the same way an automatic clearing's own `trades`
        are read back rather than recomputed (`trades_of`) -- a replay
        trusts what the table found once, live, and does not re-ask any
        gate to agree a second time.
        """
        # true state: the journal is the record of everything that
        # happened, including outcomes no view would expose.
        state = game.state(0, hidden=False)
        self._emit(
            {
                "kind": "trade",
                "step": step,
                "round": round_num,
                "trade": [trade.a, trade.b, list(trade.received)],
                "hands": [hand[:] for hand in state.hands],
            }
        )

    def note(self, *, step: int, round_num: int, note) -> None:
        """One step of a trade round (`webplay.RoundNote`, via
        `GameSession._note`): the offer, a seat's answer, the actor
        declining, everyone having passed. Discrete -- every step its own
        line, the way the record keeps every action -- while the transcript
        a reader sees folds them (`webplay.render_log`). Nothing moved, so
        no hands are written; `step` is the step this preceded, which is
        where `notes_of`/`GameSession.restore` put it back."""
        self._emit(
            {
                "kind": "note",
                "step": step,
                "round": round_num,
                "note": note.kind,
                "seat": note.seat,
                "actor": note.actor,
                "bundle": None if note.bundle is None else list(note.bundle),
            }
        )

    def undo(self, game: Game, *, back_to: int) -> None:
        """The human took a placement back (see `webplay.undo_last_build`).

        Written down rather than erased. The file is append-only and read
        forwards, so a reader that silently reused a step number would have two
        different actions claiming to be step N with nothing to say which one
        counted. This says which: everything from `back_to` onwards did not
        happen, and the steps that follow start again from there.
        """
        # true state: the journal is the record of everything that
        # happened, including outcomes no view would expose.
        state = game.state(0, hidden=False)
        self._emit(
            {
                "kind": "undo",
                "back_to": back_to,
                "hands": [hand[:] for hand in state.hands],
                "dev": [holdings(state, p) for p in range(state.num_players)],
                "deck_left": len(state.deck),
            }
        )

    def seated(self, *, seat: int, name: str, spec: str, client: dict | None = None) -> None:
        """A seat's occupant, named after the deal: a different bot swapped
        in mid-game, or an open seat somebody joined after the header was
        already written (see `api.GameSession.claim`). `spec` is empty for a
        person — there is no checkpoint to name — which the header's own
        `bots` map already treats as absent from it, so a resumed table
        only ever re-seats an actual bot from this. `client` is the same
        record the header's `clients` map carries, `None` for a bot swap."""
        self._emit(
            {"kind": "seated", "at": _now(), "seat": seat, "name": name, "spec": spec, "client": client}
        )

    def locked(self, seat: int, *, at_step: int) -> None:
        """`seat` was closed outright while it was still empty (see
        `api.Tables.close_seat`) — retired for the rest of the
        game. The reader that puts a table back (`locked_seats`, see
        `api.reopen_session`) only needs to know *that* a seat locked, not
        when: see `hexset.server.seating`'s own note on why pre-seeding the
        whole set before replay reproduces the same snake the live game
        actually walked. `at_step` is diagnostic only."""
        self._emit({"kind": "locked", "at": _now(), "seat": seat, "at_step": at_step})

    def unlocked(self, seat: int, *, at_step: int) -> None:
        """`seat` was reopened (see `api.Tables.open_seat`) -- only ever
        before the first move, so `at_step` is always 0 and diagnostic
        only. `locked_seats` reads the two kinds in order."""
        self._emit({"kind": "unlocked", "at": _now(), "seat": seat, "at_step": at_step})

    def reopened(self, *, at_step: int) -> None:
        """This game was put back together from the lines above — a server
        restart, or a session evicted for going quiet (see `webplay.resume`).

        Written so the join shows. Without it the file reads as uninterrupted
        play, and the bots' own random streams do not survive a resume, so a
        reader comparing two halves of one file needs to know where the seam
        is.
        """
        self._emit({"kind": "reopened", "at": _now(), "at_step": at_step})

    def abandoned(self) -> None:
        """The human pressed New Game, or the table was evicted for going
        quiet (`api.Table.close`), which ends this game as surely as winning
        does — for playing on, at least. Without this line the file reads as
        a game still in flight, and the one they chose to walk away from
        would be waiting for them on their next visit.

        Not the same closing line as `finish` and deliberately so: this one
        says the game stopped, `finish`'s says it *ended*. Only the game
        itself, replayed, says which (`api.reopen_session` asks `is_over`),
        and only the second is worth reopening to look at."""
        self._emit({"kind": "abandoned", "at": _now()})

    def finish(self, game: Game) -> None:
        """The closing line. A journal without one is a game that was abandoned
        rather than played out, which is the distinction anything counting
        results has to make."""
        # true state: the journal is the record of everything that
        # happened, including outcomes no view would expose.
        state = game.state(0, hidden=False)
        self._emit(
            {
                "kind": "result",
                "at": _now(),
                "winner": game.won_by,
                "turns": game.turns,
                "points": [victory_points(state, p) for p in range(state.num_players)],
            }
        )


def open_journal(seed: int, directory: str | None = None) -> Journal | None:
    """A journal for a game about to be dealt, or `None` when journalling is
    off. `directory` overrides the environment, for callers (tests, mostly)
    that would rather say where than set a variable."""
    where = directory if directory is not None else configured_dir()
    if not where:
        return None
    return Journal(directory=where, game_id=new_game_id(seed))


# --- Reading one back ---------------------------------------------------------


# The lines that mean nothing further will ever be appended to this file:
# played out (`result`) or walked away from (`abandoned`). Anything else
# leaves the file open. Note what this does *not* say — which of the two it
# was: an abandoned game is unfinished, and `is_closed` alone would file it
# alongside a game somebody won. `api.reopen_session` asks the replayed game
# itself (`is_over`) rather than this.
CLOSING_KINDS = frozenset({"result", "abandoned"})


def read(path: Path | str) -> list[dict]:
    """Every event in a journal, in the order it was written.

    Stops at the first line that will not parse instead of raising. Lines are
    appended one at a time, so the only line that can be torn is the last one
    — a server killed mid-write — and everything before it is a complete
    account that should still be readable.
    """
    events: list[dict] = []
    try:
        with open(path, encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                try:
                    events.append(json.loads(line))
                except json.JSONDecodeError:
                    break
    except OSError:
        return []
    return events


def header_of(path: Path | str) -> dict | None:
    """A journal's opening line alone, without reading the rest of it.

    `most_recent` looks at every file in the directory to find one browser's
    game, and these run to tens of thousands of lines; only the one that
    matches is worth reading in full.
    """
    try:
        with open(path, encoding="utf-8") as handle:
            first = handle.readline()
    except OSError:
        return None
    try:
        event = json.loads(first)
    except json.JSONDecodeError:
        return None
    return event if event.get("kind") == "game" else None


def is_closed(events: list[dict]) -> bool:
    return any(event.get("kind") in CLOSING_KINDS for event in events)


def action_of(event: dict) -> Action:
    """The `Action` an action line describes. The recorded effects — the dice,
    the card drawn, the card stolen — are deliberately not used: they are the
    engine's to decide again from the same seed, and reading them back would
    turn a check that the replay agrees into a way of papering over that it
    does not."""
    return Action(ActionType[event["type"]], event["a"], event["b"])


def trades_of(event: dict) -> tuple[Trade, ...]:
    """The exchanges an action line cleared. Unlike the effects above these
    *are* read back and re-executed: they are not a function of the action
    and the seed, but of what every seat had published at the time, which the
    replay has no way to reconstruct."""
    return tuple(Trade(a, b, tuple(received)) for a, b, received in event.get("trades", ()))


def replayable(events: list[dict]) -> list[tuple[int, Action | None, tuple[Trade, ...]]]:
    """Every (actor, action, trades) to re-apply, in order.

    `action` is `None` for a `"trade"` line (`Journal.manual_trade`): a
    manually executed trade replays as its own step, not attached to any
    action, since none happened when it cleared live either
    (`GameSession.restore`).

    Undo lines are honoured by dropping what they took back. The file is
    append-only — an undone placement is still written down, by design (see
    `Journal.undo`) — so replaying the lines as they come would build the
    board the human explicitly rejected.
    """
    steps: list[tuple[int, Action | None, tuple[Trade, ...]]] = []
    for event in events:
        kind = event.get("kind")
        if kind == "action":
            steps.append((event["actor"], action_of(event), trades_of(event)))
        elif kind == "trade":
            a, b, received = event["trade"]
            steps.append((a, None, (Trade(a, b, tuple(received)),)))
        elif kind == "undo":
            del steps[event["back_to"] :]
    return steps


def notes_of(events: list[dict]) -> dict[int, list[tuple[int, RoundNote]]]:
    """The trade-round steps (`Journal.note`) as `(round, RoundNote)`,
    keyed by the step each preceded, for `GameSession.restore`. An undo
    drops the notes it took back the same way `replayable` drops the steps:
    everything from `back_to` onwards did not happen."""
    from .webplay import RoundNote  # local at run time: webplay imports this module

    notes: dict[int, list[tuple[int, RoundNote]]] = {}
    for event in events:
        kind = event.get("kind")
        if kind == "note":
            bundle = event.get("bundle")
            notes.setdefault(int(event["step"]), []).append(
                (
                    int(event["round"]),
                    RoundNote(
                        str(event["note"]), int(event["seat"]), int(event["actor"]),
                        None if bundle is None else tuple(int(n) for n in bundle),
                    ),
                )
            )
        elif kind == "undo":
            for step in [s for s in notes if s >= event["back_to"]]:
                del notes[step]
    return notes


def seating(events: list[dict]) -> dict[int, tuple[str, str]]:
    """Seat -> the (name, spec) of the bot on it: the lineup the game was
    dealt with, with every later swap or bot claim applied in the order they
    happened. A `seated` event for a person rather than a bot carries an
    empty `spec` (see `Journal.seated`) and is skipped here -- this map is
    bots only, which is what a table rebuilding after a restart needs to
    know which seats to re-seat automatically (see `api.Tables._reopen`).
    `players` below is the other half of that split, read the same way."""
    header = events[0] if events else {}
    seats = {
        int(seat): (bot["name"], bot["spec"])
        for seat, bot in header.get("bots", {}).items()
    }
    for event in events:
        if event.get("kind") == "seated":
            if event["spec"]:
                seats[event["seat"]] = (event["name"], event["spec"])
            else:
                seats.pop(event["seat"], None)
    return seats


def players(events: list[dict]) -> dict[int, str]:
    """Seat -> the name of the person (or LLM) holding it: `seating`'s exact
    complement, and read the same way.

    The seats are the header's own `human_seats` less the ones its `bots` map
    claims (that field is every seat occupied at deal time, whichever kind —
    see `Journal.start`), named from `player_names`; a seat nobody named
    comes back with an empty string rather than being left out, since *that a
    seat was somebody's* is the thing this map exists to say. Every later
    `seated` event is folded on top exactly as `seating` folds them, with the
    test inverted: an empty `spec` is a person taking a seat
    (`api.GameSession.claim`) and puts them in this map, a `spec` is a bot
    taking one (`api.Tables.seat_bot`) and takes the seat out of it.

    `api.Tables._reopen` rebuilds these seats as claimed-but-untokened, which
    is what makes a reopened game's own seats stop looking open to
    `Table.join`: the token is gone for good (it never touches disk — see
    `api.py`'s module docstring) and `POST /api/reclaim` is how whoever held
    the seat proves it is still theirs.
    """
    header = events[0] if events else {}
    names = header.get("player_names", {})
    bots = set(header.get("bots", {}))
    seats = {
        int(seat): names.get(str(seat), "")
        for seat in header.get("human_seats", [])
        if str(seat) not in bots
    }
    for event in events:
        if event.get("kind") == "seated":
            if event["spec"]:
                seats.pop(event["seat"], None)
            else:
                seats[event["seat"]] = event.get("name") or ""
    return seats


def clients(events: list[dict]) -> dict[int, dict]:
    """Seat -> its client record (`{"id", "kind"}`), from the header's own
    `clients` map with every later `seated` event's `client` applied on top
    -- the same fold `seating` does for bots, so a seat's identity for
    `POST /api/reclaim` survives a restart (`api.Tables._reopen`) the same
    way a bot's spec does. A seat with no client anywhere is left out."""
    header = events[0] if events else {}
    result = {int(seat): client for seat, client in header.get("clients", {}).items() if client}
    for event in events:
        if event.get("kind") == "seated" and event.get("client"):
            result[event["seat"]] = event["client"]
    return result


def locked_seats(events: list[dict]) -> frozenset[int]:
    """The seats closed at the end of the record (`Journal.locked`, less
    any later `Journal.unlocked`). Pre-seeding the whole set before replay
    reproduces the exact same snake the live game walked (see
    `hexset.server.seating`'s own note on why): every close and reopen
    happened before the first move, so only the final set matters."""
    locked: set[int] = set()
    for event in events:
        if event.get("kind") == "locked":
            locked.add(event["seat"])
        elif event.get("kind") == "unlocked":
            locked.discard(event["seat"])
    return frozenset(locked)


def most_recent(directory: str | None, code: str) -> Path | None:
    """The most recent file filed under join code `code`, closed or not, or
    `None` if there isn't one.

    Closed or not on purpose: a finished game is still worth handing back
    (there is nothing left to play, but the whole of it is still worth
    reading), and `is_closed` alone cannot tell a game that was played out
    from one that was walked away from — both write a closing line. Which
    of the three a file is, is `api.reopen_session`'s to decide from the
    replayed game itself, not this function's to guess from the file.

    Only the most recent file bearing that code is ever a candidate. An older
    game under the same code — closed or not — is one the table already
    walked away from once; handing it back would be reaching further into
    the past than anyone asked for.

    Matched without regard to case, for the same reason `api.Tables.get`
    normalises one: case is not part of a code's identity. It also means a
    game journalled back when codes were written in capitals is still found
    by the lowercase code that now addresses it.
    """
    if not directory:
        return None
    wanted = code.lower()
    try:
        paths = sorted(Path(directory).glob("*.jsonl"), reverse=True)
    except OSError:
        return None
    for path in paths:
        header = header_of(path)
        if header is None or str(header.get("code") or "").lower() != wanted:
            continue
        return path
    return None


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
